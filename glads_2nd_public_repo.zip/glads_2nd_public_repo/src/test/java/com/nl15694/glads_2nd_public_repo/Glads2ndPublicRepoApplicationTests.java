package com.nl15694.glads_2nd_public_repo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Glads2ndPublicRepoApplicationTests {

	@Test
	void contextLoads() {
	}

}
